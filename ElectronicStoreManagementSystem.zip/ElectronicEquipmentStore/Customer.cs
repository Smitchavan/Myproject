﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicEquipmentStore
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
            DisplayCustomers();
        }
        SqlConnection Con=new SqlConnection(@"Data Source=DESKTOP-EQMGRFQ;Initial Catalog=electronic store;Integrated Security=True");
        private void DisplayCustomers()
        {
            Con.Open();
            string Query = "Select * from Customer ";
            SqlDataAdapter sda=new SqlDataAdapter(Query,Con);
            SqlCommandBuilder builder=new SqlCommandBuilder(sda );
            var ds=new DataSet();
            sda.Fill(ds);
            Customert.DataSource=ds.Tables[0];
            Con.Close();
        }
        private void Clear()
        {
            CustN.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (CustN.Text == "")
            {
                MessageBox.Show("Missing info");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into Customer(CName)values(@CN)", Con);
                    cmd.Parameters.AddWithValue("@CN", CustN.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Added");
                    Con.Close();
                    DisplayCustomers();
                    Clear();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        int Key=0;
        private void Customert_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CustN.Text = Customert.SelectedRows[0].Cells[1].Value.ToString();
            if(CustN.Text=="")
            {
                Key = 0;
            }
            else
            {
                Convert.ToInt32(Customert.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                if (Key==0)
                {
                    MessageBox.Show("Select an Customer");
                }
                else
                {
                    try
                    {
                        Con.Open();
                        SqlCommand cmd = new SqlCommand("delete from Customer where Cid=@CKey ", Con);
                        cmd.Parameters.AddWithValue("@CKey", Key);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Customer Deleted");
                        Con.Close();
                        DisplayCustomers();
                        Clear();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }
                }
            }

        }
    }
}
