﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicEquipmentStore
{
    public partial class Bills : Form
    {
        public Bills()
        {
            InitializeComponent();
            GetCustomers();
            DisplayProducts();
            DisplayTransaction();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-EQMGRFQ;Initial Catalog=electronic store;Integrated Security=True");
        private void GetCustomers()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select Cid from Customer", Con);
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Cid", typeof(int));
            dt.Load(reader);
            CI.ValueMember = "Cid";
            CI.DataSource = dt;
            Con.Close();

        }
        private void GetCustName()
        {
            Con.Open();
            string Query = "Select * from Customer where Cid='" + CI.SelectedValue.ToString();
            SqlCommand cmd = new SqlCommand(Query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                CN.Text = dr["Cid"].ToString();
            }
            Con.Close();



        }
        private void DisplayProducts()
        {
            Con.Open();
            string Query = "Select * from Products";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            prod.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void DisplayTransaction()
        {
            Con.Open();
            string Query = "Select * from Bill";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            tran.DataSource = ds.Tables[0];
            Con.Close();
        }
        
        private void InsertBill()
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("insert into Bill(Bdate,Cid,Cname,Amt)values(@BD,@CI,@CN,@AM)", Con);
                cmd.Parameters.AddWithValue("@BD", DateTime.Today.Date);
                cmd.Parameters.AddWithValue("@CI", CI.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@CN", CN.Text);
                cmd.Parameters.AddWithValue("@AM", GrdTotal);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Bill Saved");
                Con.Close();
                DisplayTransaction();
                // Clear();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void UpdateStock()
        {
            int NewQty = Stock - Convert.ToInt32(PQ.Text);
            try
            {
                
                Con.Open();
                SqlCommand sqlCommand = new SqlCommand("Update Products set Pquan=" + NewQty + " where Pid=" + Key + "",Con);
                SqlCommand cmd = sqlCommand;
                cmd.Parameters.AddWithValue("@PQ", NewQty);
                cmd.Parameters.AddWithValue("@PKey", Key);
                cmd.ExecuteNonQuery();
                Con.Close();
                DisplayProducts();

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        int n = 0, GrdTotal = 0;
        int Key = 0, Stock = 0;
        private void Pro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            PN.Text = prod.SelectedRows[0].Cells[1].Value.ToString();
            Stock = Convert.ToInt32(prod.SelectedRows[0].Cells[3].Value.ToString());
            PP.Text = prod.SelectedRows[0].Cells[2].Value.ToString();
            if (PQ.Text == "")
            {
                Key = 0;
            }

            else
            {
                Key = Convert.ToInt32(prod.SelectedRows[0].Cells[0].Value.ToString());
            }
        }
        private void Reset()
        {
            PQ.Text = "";
            PN.Text = "";
            PP.Text = "";
            Key = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertBill();
            printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 285, 600);
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (PQ.Text == "" || Convert.ToInt32(PQ.Text) > Stock)
            {
                MessageBox.Show("Not enough in house");
            }
           
            
            else
            {
                int total = Convert.ToInt32(PQ.Text) * Convert.ToInt32(PP.Text);
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(print);
                newRow.Cells[0].Value = n + 1;
                newRow.Cells[1].Value = PN.Text;
                newRow.Cells[2].Value = PQ.Text;
                newRow.Cells[3].Value = PP.Text;
                newRow.Cells[4].Value = total;
                GrdTotal = GrdTotal + total;
                print.Rows.Add(newRow);
                n++;
                mon.Text = "Rs" + GrdTotal;
                UpdateStock();
                Reset();
            }
        }

        private void CN_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void CI_SelectedIndexChanged(object sender, EventArgs e)
        {
         


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
