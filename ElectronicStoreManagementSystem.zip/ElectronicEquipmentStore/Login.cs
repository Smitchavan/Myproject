﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicEquipmentStore
{
    public partial class Login : Form
    {
        static SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EQMGRFQ;Initial Catalog=electronic store;Integrated Security=True");
        static SqlCommand poke;
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void register_Click(object sender, EventArgs e)
        {
           
        
        Register reg = new Register();
        reg.ShowDialog();
        }

        private void Log_Click(object sender, EventArgs e)
        {
            bool isuserok = false, ispassok = false;
            if (!Authenticate())
            {
                MessageBox.Show("Boxes are empty");
                return;
            }
            string query = "SELECT * FROM Register WHERE usern=@USER ";
            con.Open();
            poke = new SqlCommand(query, con);

            poke.Parameters.Add("@USER", SqlDbType.VarChar);
            poke.Parameters["@USER"].Value = User.Text;

            SqlDataReader smit = poke.ExecuteReader();
            if (smit.HasRows)
            {
                isuserok = true;
            }
                con.Close();
            con.Open();
            query = "SELECT * FROM Register WHERE usern=@USER AND pass=@PASS ";
            poke = new SqlCommand(query, con);

            poke.Parameters.Add("@USER", SqlDbType.VarChar);
            poke.Parameters["@USER"].Value = User.Text;

            poke.Parameters.Add("@PASS", SqlDbType.VarChar);
            poke.Parameters["@PASS"].Value = Pass.Text;

            smit = poke.ExecuteReader();
            if(smit.HasRows)
            {
                ispassok=true;
            }

            if(isuserok==false)
            {
                MessageBox.Show("User does not exists");
            }
            else if(isuserok==true&&ispassok==false)
                {
                MessageBox.Show("Renter Password");
            }
            else
            {   Hide();
                MAINFORM main = new MAINFORM();
                main.ShowDialog();
                Close();
            }
            con.Close();
        }
        bool Authenticate()
        {
            if (string.IsNullOrWhiteSpace(User.Text) ||
                string.IsNullOrWhiteSpace(Pass.Text) 
                       
                )
                return false;
            else return true;
        }
    }
    }

