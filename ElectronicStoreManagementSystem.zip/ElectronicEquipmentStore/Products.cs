﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicEquipmentStore
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
            DisplayProducts();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-EQMGRFQ;Initial Catalog=electronic store;Integrated Security=True");
        private void DisplayProducts()
        {
            Con.Open();
            string Query = "Select * from Products ";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            Pro.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Clear()
        {
            PN.Text = "";
            PC.SelectedIndex = 0;
            PQ.Text = "";
            PP.Text = "";
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                if (PN.Text == ""||PC.SelectedIndex==-1||PQ.Text==""||PP.Text=="")
                {
                    MessageBox.Show("Missing info");
                }
                else
                {
                    try
                    {
                        Con.Open();
                        SqlCommand cmd = new SqlCommand("insert into Products(Pname,Pprice,Pquan,Pcat)values(@PN,@PP,@PQ,@PC)", Con);
                        cmd.Parameters.AddWithValue("@PN",PN.Text);
                        cmd.Parameters.AddWithValue("@PP", PP.Text);
                        cmd.Parameters.AddWithValue("@PQ", PQ.Text);
                        cmd.Parameters.AddWithValue("@PC", PC.SelectedItem.ToString());
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product Added");
                        Con.Close();
                        DisplayProducts();
                        Clear();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }
                }
            }
        }
        int Key = 0;
        private void Pro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                PN.Text = Pro.SelectedRows[0].Cells[1].Value.ToString();
                PQ.Text = Pro.SelectedRows[0].Cells[2].Value.ToString();
                PC.Text = Pro.SelectedRows[0].Cells[3].Value.ToString();
                PP.Text = Pro.SelectedRows[0].Cells[4].Value.ToString();
                if (PN.Text == "")
                {
                    Key = 0;
                }
                else
                {
                    Key = Convert.ToInt32(Pro.SelectedRows[0].Cells[0].Value.ToString());
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                if (Key == 0)
                {
                    MessageBox.Show("Select a Product");
                }
                else
                {
                    try
                    {
                        Con.Open();
                        SqlCommand cmd = new SqlCommand("delete from Products where Pid=@PKey ", Con);
                        cmd.Parameters.AddWithValue("@PKey", Key);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product Deleted");
                        Con.Close();
                        DisplayProducts();
                        Clear();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }
                }
            }
        }
    }
}
