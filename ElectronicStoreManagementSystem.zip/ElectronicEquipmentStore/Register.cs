﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicEquipmentStore
{
    public partial class Register : Form
    {
        static SqlConnection con= new SqlConnection(@"Data Source=DESKTOP-EQMGRFQ;Initial Catalog=electronic store;Integrated Security=True");
        static SqlCommand poke;
        public Register()
        {
            InitializeComponent();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
                if(!Authenticate())
            {
                MessageBox.Show("Boxes are empty");
                return;
            }
            string query = "INSERT INTO Register Values(@NAME,@GENDER,@USER,@PASS)";
            con.Open(); 
            poke=new SqlCommand(query,con);

            poke.Parameters.Add("@NAME", SqlDbType.VarChar);
            poke.Parameters["@NAME"].Value = Cust.Text;

            poke.Parameters.Add("@GENDER", SqlDbType.VarChar);
            poke.Parameters["@GENDER"].Value = Phone.Text;

            poke.Parameters.Add("@USER", SqlDbType.VarChar);
            poke.Parameters["@USER"].Value = User.Text;

            poke.Parameters.Add("@PASS", SqlDbType.VarChar);
            poke.Parameters["@PASS"].Value = Pass.Text;

            poke.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("DATA SAVED SUCCESSFULLY");
        }
         bool Authenticate()
        {
            if (string.IsNullOrWhiteSpace(User.Text) ||
                string.IsNullOrWhiteSpace(Pass.Text) ||
                string.IsNullOrWhiteSpace(Phone.Text) ||
                string.IsNullOrWhiteSpace(Cust.Text)
                )
                return false;
            else return true;
            
        }
       



        }
    
}
