﻿namespace ElectronicEquipmentStore
{
    partial class Bills
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bills));
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CI = new System.Windows.Forms.ComboBox();
            this.CN = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.PP = new System.Windows.Forms.TextBox();
            this.PQ = new System.Windows.Forms.TextBox();
            this.print = new System.Windows.Forms.DataGridView();
            this.PN = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.prod = new System.Windows.Forms.DataGridView();
            this.tran = new System.Windows.Forms.DataGridView();
            this.label13 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.mon = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productquan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.print)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tran)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 27);
            this.label8.TabIndex = 17;
            this.label8.Text = "Billing";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 228);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 18;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(25, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(121, 46);
            this.panel2.TabIndex = 20;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.CI);
            this.panel1.Controls.Add(this.CN);
            this.panel1.Location = new System.Drawing.Point(183, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(190, 92);
            this.panel1.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poor Richard", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 19);
            this.label2.TabIndex = 21;
            this.label2.Text = "Customer Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poor Richard", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 19);
            this.label1.TabIndex = 21;
            this.label1.Text = "Customer Id";
            // 
            // CI
            // 
            this.CI.FormattingEnabled = true;
            this.CI.Items.AddRange(new object[] {
            "Mobiles",
            "Television",
            "Refrigerator",
            "Washing Machine"});
            this.CI.Location = new System.Drawing.Point(3, 19);
            this.CI.Name = "CI";
            this.CI.Size = new System.Drawing.Size(102, 21);
            this.CI.TabIndex = 11;
            this.CI.SelectedIndexChanged += new System.EventHandler(this.CI_SelectedIndexChanged);
            // 
            // CN
            // 
            this.CN.Location = new System.Drawing.Point(3, 65);
            this.CN.Name = "CN";
            this.CN.Size = new System.Drawing.Size(178, 20);
            this.CN.TabIndex = 1;
            this.CN.TextChanged += new System.EventHandler(this.CN_TextChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(58, 47);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 10;
            this.button3.Text = "Reset";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(693, 218);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Print";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PP
            // 
            this.PP.Location = new System.Drawing.Point(215, 21);
            this.PP.Name = "PP";
            this.PP.Size = new System.Drawing.Size(77, 20);
            this.PP.TabIndex = 1;
            // 
            // PQ
            // 
            this.PQ.Location = new System.Drawing.Point(135, 21);
            this.PQ.Name = "PQ";
            this.PQ.Size = new System.Drawing.Size(74, 20);
            this.PQ.TabIndex = 1;
            // 
            // print
            // 
            this.print.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.print.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.print.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.productname,
            this.productquan,
            this.productprice,
            this.total});
            this.print.Location = new System.Drawing.Point(488, 12);
            this.print.Name = "print";
            this.print.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.print.Size = new System.Drawing.Size(493, 200);
            this.print.TabIndex = 0;
            this.print.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Pro_CellContentClick);
            // 
            // PN
            // 
            this.PN.Location = new System.Drawing.Point(3, 21);
            this.PN.Name = "PN";
            this.PN.Size = new System.Drawing.Size(130, 20);
            this.PN.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(159, 48);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "Add to Bill";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.PN);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.PQ);
            this.panel3.Controls.Add(this.PP);
            this.panel3.Location = new System.Drawing.Point(183, 110);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(295, 83);
            this.panel3.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Poor Richard", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(131, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 19);
            this.label5.TabIndex = 21;
            this.label5.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Poor Richard", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(238, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 19);
            this.label4.TabIndex = 21;
            this.label4.Text = "Price";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poor Richard", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 19);
            this.label3.TabIndex = 21;
            this.label3.Text = "Product Name";
            // 
            // prod
            // 
            this.prod.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.prod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prod.Location = new System.Drawing.Point(159, 238);
            this.prod.Name = "prod";
            this.prod.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.prod.Size = new System.Drawing.Size(490, 200);
            this.prod.TabIndex = 0;
            this.prod.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Pro_CellContentClick);
            // 
            // tran
            // 
            this.tran.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.tran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tran.Location = new System.Drawing.Point(667, 300);
            this.tran.Name = "tran";
            this.tran.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tran.Size = new System.Drawing.Size(314, 150);
            this.tran.TabIndex = 0;
            this.tran.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Pro_CellContentClick);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Modern No. 20", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(272, 198);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(157, 38);
            this.label13.TabIndex = 9;
            this.label13.Text = "Products";
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // mon
            // 
            this.mon.AutoSize = true;
            this.mon.Location = new System.Drawing.Point(788, 223);
            this.mon.Name = "mon";
            this.mon.Size = new System.Drawing.Size(18, 13);
            this.mon.TabIndex = 9;
            this.mon.Text = "@";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(733, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(222, 38);
            this.label6.TabIndex = 9;
            this.label6.Text = "Transactions";
            // 
            // Id
            // 
            this.Id.HeaderText = "Identity";
            this.Id.Name = "Id";
            // 
            // productname
            // 
            this.productname.HeaderText = "Product Name";
            this.productname.Name = "productname";
            // 
            // productquan
            // 
            this.productquan.HeaderText = "Quantity";
            this.productquan.Name = "productquan";
            // 
            // productprice
            // 
            this.productprice.HeaderText = "Price";
            this.productprice.Name = "productprice";
            // 
            // total
            // 
            this.total.HeaderText = "Total";
            this.total.Name = "total";
            // 
            // Bills
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(993, 450);
            this.Controls.Add(this.tran);
            this.Controls.Add(this.prod);
            this.Controls.Add(this.print);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.mon);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "Bills";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.print)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tran)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox CI;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox PP;
        private System.Windows.Forms.TextBox PQ;
        private System.Windows.Forms.TextBox CN;
        private System.Windows.Forms.DataGridView print;
        private System.Windows.Forms.TextBox PN;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView prod;
        private System.Windows.Forms.DataGridView tran;
        private System.Windows.Forms.Label label13;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label mon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn productname;
        private System.Windows.Forms.DataGridViewTextBoxColumn productquan;
        private System.Windows.Forms.DataGridViewTextBoxColumn productprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
    }
}