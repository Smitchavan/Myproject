﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ElectronicEquipmentStore
{
    public partial class MAINFORM : Form
    {
        public MAINFORM()
        {
            InitializeComponent();
        }

        

        private void MAINFORM_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
            MAINFORM main = new MAINFORM();
            main.ShowDialog(); 
          
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
            Products prod = new Products();
            prod.ShowDialog();
         
        }

        private void bunifuProgressBar1_progressChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
            Customer cus = new Customer();
            cus.ShowDialog();
            
        }

        private void label4_Click(object sender, EventArgs e)
        {
           
            Bills bi = new Bills();
            bi.ShowDialog();
            
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Login lo = new Login();
            lo.ShowDialog();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
